<?php

namespace App\Http\Controllers\Home;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use ZipArchive;

class DocumentoController extends Controller {
    public function __construct(Request $request)
    {
        $this->request = $request;
    }

    public function propietarios($template, $arg){
        // Create the Object.
        $zip = new ZipArchive();

        $filename = __DIR__ . "\\..\\..\\..\\Templates\\". $template ."_TEMPLATE.docx";
        $newfilename = __DIR__ . "\\..\\..\\..\\Templates\\". $template ."_TEMPLATE_".$arg["NOMBRE"].".docx";

        if (!copy($filename, $newfilename)) {
            echo "failed to copy"; die;
        }

        // Open the Microsoft Word .docx file as if it were a zip file... because it is.
        if ($zip->open($newfilename, ZipArchive::CREATE)!==TRUE) {
            echo "Cannot open $newfilename :( "; die;
        }

        // Fetch the document.xml file from the word subdirectory in the archive.
        $xml = $zip->getFromName('word/document.xml');

        foreach ($arg as $key => $value) {
            $xml = str_replace("${".$key."}", (empty($arg[$key]) ? "" : $arg[$key]), $xml);
        }

        // Write back to the document and close the object
        if ($zip->addFromString('word/document.xml', $xml)) { echo 'File written!'; }
        else { echo 'File not written.  Go back and add write permissions to this folder!l'; }

        $zip->close();
    }
}
?>